import{_ as e,e as c,f as o}from"./index.4ad41eec.js";const r={};function n(t,s){return c(),o("div")}const a=e(r,[["render",n]]);export{a as default};
