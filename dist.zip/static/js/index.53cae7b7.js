import{r as o}from"./index.0692c036.js";function e(){return o({url:"/moyin/websiteConfig/getUserProtocol",method:"GET"})}export{e as g};
