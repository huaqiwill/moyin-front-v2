import{_ as e,d as c,e as o}from"./index.5bf14814.js";const r={};function n(t,s){return c(),o("div")}const a=e(r,[["render",n]]);export{a as default};
