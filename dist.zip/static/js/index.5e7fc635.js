import{_ as e,e as c,f as o}from"./index.25973d8c.js";const r={};function n(t,s){return c(),o("div")}const a=e(r,[["render",n]]);export{a as default};
